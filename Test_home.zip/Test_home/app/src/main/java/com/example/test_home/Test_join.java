package com.example.test_home;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Test_join extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_join);
    }
}
