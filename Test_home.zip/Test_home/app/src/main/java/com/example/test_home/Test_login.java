package com.example.test_home;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Test_login extends AppCompatActivity {
    Button Button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_login);
        Button=(Button)findViewById(R.id.button2);
        Button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if (view.getId() == R.id.button2) {
                    Intent intent = new Intent(getApplicationContext(), Test_join.class);
                    startActivity(intent);
                }
            }
        });
    }
    public void login(View v)
    {
        Toast.makeText(getApplicationContext(),"로그인 되었습니다!",Toast.LENGTH_LONG).show();
        finish();
    }
}
